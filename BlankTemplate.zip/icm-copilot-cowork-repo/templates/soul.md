# Voice

## How I sound
[e.g. Plain, direct, friendly. Short sentences. No jargon.]

## Rules
- Greeting: [e.g. first name only, no "Dear"].
- Sign-off: [e.g. "Kind regards," external; "Thanks!" quick internal].
- Never write: [phrases you can't stand — e.g. "leverage", "circle back", "hope this finds you well"].
- Spelling: [e.g. UK/Irish — organise, colour, centre].

## Example
**Good:** [paste a couple of lines that sound like you]

**Bad:** [paste something that definitely doesn't]
