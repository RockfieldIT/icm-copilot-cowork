# [Room name]

## What this room does
[One paragraph: the type of work and what you want help with here.]

## Process
1. [Step one.]
2. [Step two.]
3. [Step three.]

## What good looks like
- [3–5 bullets describing an ideal result. Be specific.]

## Constraints
- [Anything the assistant must never do here.]
- [Anything it must always do.]

Load `soul.md` for voice. Add `_config/` references if this room needs them.
