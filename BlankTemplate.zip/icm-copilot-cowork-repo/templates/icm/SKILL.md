---
name: icm
description: Load and work inside my ICM workspace. Use when I type /icm, or
  when I'm doing my regular work (email, drafting, reports, and so on).
---

Read `ICM/setup.md` in my OneDrive and follow its routing table. Load only the
room and "also load" files the task needs. Stay within the ICM structure until
I say otherwise.
