# [Your name] — Copilot Workspace (ICM)

Routing file. Read this first, then load the room and any "also load" files the
task needs.

## About me
[Name], [role] at [organisation]. [One line on what the organisation does.]

## Folder map
```
ICM/
├── setup.md
├── soul.md
├── _config/style.md
├── email/CONTEXT.md
├── drafting/CONTEXT.md
└── reports/CONTEXT.md
```

## Routing
| Task | Room | Also load |
|------|------|-----------|
| Triage or reply to email | email/CONTEXT.md | soul.md |
| Write a document or proposal | drafting/CONTEXT.md | soul.md, _config/style.md |
| Write a report or update | reports/CONTEXT.md | soul.md |

## Rules
- Read this file first; load only the room(s) the task needs.
- Never send anything on my behalf without my explicit approval.
- [Add your own standing rules.]
