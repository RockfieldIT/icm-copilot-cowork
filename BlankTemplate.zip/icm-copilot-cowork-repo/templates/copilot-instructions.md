# Personal Copilot instructions

## Default workspace — ICM
For any work task, treat the ICM workspace in my OneDrive as the operating
context. Before starting, read `ICM/setup.md` and follow its routing table:
load only the room (and any "also load" files) the task needs.

- Never send email or messages on my behalf without explicit approval.
- [Add any other standing rules.]
