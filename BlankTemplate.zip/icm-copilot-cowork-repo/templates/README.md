# ICM for Copilot Cowork — Starter Templates

Fillable starter files for the guide in this repo (see [`../README.md`](../README.md)).
Replace the `[PLACEHOLDERS]` and delete any instructions in italics.

## What goes where (in your OneDrive)

| File | Put it in |
|------|-----------|
| `setup.md` | the root of your `ICM/` folder |
| `soul.md` | the root of your `ICM/` folder |
| `CONTEXT.md` | each room folder, one per room (e.g. `ICM/email/CONTEXT.md`) |
| `copilot-instructions.md` | your Cowork folder in OneDrive (often `Documents/Cowork`) — makes ICM your default (Option 1 in the guide) |
| `icm/SKILL.md` | your Cowork skills folder, in a folder named `icm` (Option 2 in the guide) |

Start with `setup.md`, `soul.md`, and one room. Add rooms over time. Keep every
file lean — see the guide's "Keep token use down" section.
